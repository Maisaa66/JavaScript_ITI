


document.addEventListener('contextmenu', event => event.preventDefault());